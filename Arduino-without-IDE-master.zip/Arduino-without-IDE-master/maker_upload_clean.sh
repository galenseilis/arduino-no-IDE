make upload monitor clean
