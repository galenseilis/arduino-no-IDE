# Arduino-without-IDE
I recently watched this [tutorial](https://www.youtube.com/watch?v=qAM2S27FWAI) on writing and uploading code to the Arduino. It requires setting up a relatively simple makefile that needs to be copied to each sketch directory, but I will likely be opting for this approach on my future Arduino projects.
